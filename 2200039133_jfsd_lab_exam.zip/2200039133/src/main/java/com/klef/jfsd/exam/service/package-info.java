package com.klef.jfsd.exam.service;

import com.klef.jfsd.exam.model.Department;
import com.klef.jfsd.exam.repository.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
public class DepartmentService {

    @Autowired
    private DepartmentRepository departmentRepository;

    @Transactional
    public void updateDepartment(Long departmentId, String name, String location) {
        Department department = departmentRepository.findById(departmentId).orElseThrow(() -> new RuntimeException("Department not found"));
        department.setName(name);
        department.setLocation(location);
        departmentRepository.save(department);
    }
}
