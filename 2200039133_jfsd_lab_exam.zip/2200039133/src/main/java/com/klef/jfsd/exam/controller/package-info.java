package com.klef.jfsd.exam.controller;

import com.klef.jfsd.exam.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class DepartmentController {

    @Autowired
    private DepartmentService departmentService;

    // Show the form for updating department details
    @GetMapping("/update-department")
    public String showUpdateForm(@RequestParam("id") Long departmentId, Model model) {
        model.addAttribute("departmentId", departmentId);
        return "update-department";  // Returns a JSP view (update-department.jsp)
    }

    // Handle the form submission for updating department
    @PostMapping("/update-department")
    public String updateDepartment(@RequestParam("id") Long departmentId, 
                                   @RequestParam("name") String name, 
                                   @RequestParam("location") String location) {
        departmentService.updateDepartment(departmentId, name, location);
        return "redirect:/departments";  // Redirect to another page after update
    }
}
